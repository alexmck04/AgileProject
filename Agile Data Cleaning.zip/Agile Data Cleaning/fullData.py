#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
This script reads data from a CSV file using pandas,
removes rows with missing values, and saves the cleaned data to a new CSV file.
"""

import pandas as pd
import numpy as np

input_path = "vgchartz-2024.csv"
output_path = "GameSales_Full.csv"

def clean_csv(input_file: str, output_file: str):
    # Read the CSV file into a pandas DataFrame
    df = pd.read_csv(input_file)

    # Print initial data info
    print("Initial Data:")
    print(df.info(), "\n")

    # Drop rows with any missing values
    cleaned_df = df.dropna()

    # Optional: reset the index after cleaning
    cleaned_df.reset_index(drop=True, inplace=True)

    # Save the cleaned data to a new CSV file
    cleaned_df.to_csv(output_file, index=False)

    # Print confirmation
    print(f"Cleaned data saved to '{output_file}'")
    print(f"Removed {len(df) - len(cleaned_df)} rows containing missing values.\n")

    # Show the first few cleaned rows
    print("Cleaned Data Preview:")
    print(cleaned_df.head())

# Example usage
if __name__ == "__main__":
    clean_csv(input_path, output_path)
