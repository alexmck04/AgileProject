#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Clean a video game sales dataset by:
- Removing rows with less than 50% complete data
- Dropping unnecessary columns (img, regional sales)
- Filling missing categorical and numeric values

total sales is represented in millions
"""

import pandas as pd

input_path = "vgchartz-2024.csv"
output_path = "GameSales_PartialCleanedNoFill.csv"


def clean_games_csv(input_file: str, output_file: str):
    # Read the CSV
    df = pd.read_csv(input_file)
    print(f"Original dataset: {len(df)} rows, {len(df.columns)} columns")

    # Drop unwanted columns
    drop_cols = ['img', 'na_sales', 'jp_sales', 'pal_sales', 'other_sales', 'last_update']
    df.drop(columns=[col for col in drop_cols if col in df.columns], inplace=True)
    print(f"Removed unnecessary columns: {[col for col in drop_cols if col in df.columns]}")

    # Calculate row completeness
    completeness = df.notna().sum(axis=1) / len(df.columns)

    # Keep rows that are at least 80% complete
    df = df[completeness >= 0.8]
    print(f"After dropping rows below 80% complete: {len(df)} rows remain")

    ### Row fillers

    # Fill important categorical columns with 'Unknown'
    #categorical_cols = ['title', 'genre', 'console', 'publisher', 'developer']
    #for col in categorical_cols:
    #    if col in df.columns:
    #        df[col] = df[col].fillna('Unknown')

    # Fill important numeric columns with their mean
    #numeric_cols = ['critic_score', 'total_sales']
    #for col in numeric_cols:
    #   if col in df.columns:
    #        df[col] = df[col].fillna(df[col].mean())

    # Final cleanup
    df.dropna(how='all', inplace=True)
    df.reset_index(drop=True, inplace=True)

    # Save the cleaned dataset
    df.to_csv(output_file, index=False)

    print(f"\nCleaned dataset saved to '{output_file}'")
    print(f"Remaining rows: {len(df)}")
    print(f"Remaining columns: {len(df.columns)}")
    print("\n🔹 Preview of cleaned data:")
    print(df.head())


if __name__ == "__main__":
    clean_games_csv(input_path, output_path)
